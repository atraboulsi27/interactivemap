package com.prodevutils.thrifty

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
