# thrifty

Insurance App flutter UI

## Screenshots

<div float="left">
<img  src = "https://raw.github.com/wekex35/insurance-app-ui/master/screenshots/onboarding.png" style="border:5px solid black" alt="Onboarding" width="240">

<img  src = "https://raw.github.com/wekex35/insurance-app-ui/master/screenshots/home1.png" style="border:5px solid black" alt="Home 1" width="240">
<img  src = "https://raw.github.com/wekex35/insurance-app-ui/master/screenshots/home2.png" style="border:5px solid black" alt="Home 2" width="240">
</div>
</br>
<div float="left">
<img  src = "https://raw.github.com/wekex35/insurance-app-ui/master/screenshots/premium.png" style="border:5px solid black" alt="Premium Screen" width="240">

<img  src = "https://raw.github.com/wekex35/insurance-app-ui/master/screenshots/contribution.png" style="border:5px solid black" alt="Contribution" width="240">
<img  src = "https://raw.github.com/wekex35/insurance-app-ui/master/screenshots/contribution2.png" style="border:5px solid black" alt="Contribution 2" width="240">
</div>
</br>
<div float="left">
<img  src = "https://raw.github.com/wekex35/insurance-app-ui/master/screenshots/coverage.png" style="border:5px solid black" alt="Coverage" width="240">

<img  src = "https://raw.github.com/wekex35/insurance-app-ui/master/screenshots/insurance_details.png" style="border:5px solid black" alt="Insurance Details" width="240">
<img  src = "https://raw.github.com/wekex35/insurance-app-ui/master/screenshots/insurance_plan.png" style="border:5px solid black" alt="CInsurance Plan" width="240">
</div>